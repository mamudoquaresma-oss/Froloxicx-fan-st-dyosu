FROLOXICX FAN STÜDYOSU

Başlatma:
1. index.html dosyasını Chrome veya başka bir tarayıcıda aç.
2. Ana Sayfa, Fan galerisi, Resim paylaş ve Hakkında düğmeleri çalışır.
3. Yüklenen görseller bu cihazdaki tarayıcı depolamasında tutulur.

ÖNEMLİ:
Bu tek dosyalık demo sürümüdür. Farklı kullanıcıların aynı ortak galeride birbirlerinin yüklemelerini görmesi için web sitesini bir sunucuya yayımlamak ve bir veritabanı/depolama hizmeti bağlamak gerekir. Şu anki sürümde resimler yalnızca bu tarayıcıda görünür.
